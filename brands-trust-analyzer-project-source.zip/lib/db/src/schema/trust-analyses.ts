import { createInsertSchema } from "drizzle-zod";
import { boolean, integer, jsonb, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export type TrustFindingRecord = {
  category: string;
  severity: "informational" | "warning" | "high" | "critical";
  observationType:
    | "confirmed"
    | "reputation"
    | "heuristic"
    | "ai_interpretation"
    | "user_provided";
  title: string;
  description: string;
  sourceUrl: string | null;
  scoreImpact: number;
};

export const trustAnalysesTable = pgTable("trust_analyses", {
  id: uuid("id").primaryKey().defaultRandom(),
  sessionOwner: text("session_owner").notNull(),
  submittedUrl: text("submitted_url").notNull(),
  domain: text("domain").notNull(),
  analysisType: text("analysis_type").notNull(),
  riskScore: integer("risk_score").notNull(),
  riskLevel: text("risk_level").notNull(),
  authenticity: text("authenticity").notNull(),
  confidence: text("confidence").notNull(),
  summary: text("summary").notNull(),
  hasAi: boolean("has_ai").notNull().default(false),
  findings: jsonb("findings").$type<TrustFindingRecord[]>().notNull(),
  warningSigns: jsonb("warning_signs").$type<string[]>().notNull(),
  positiveIndicators: jsonb("positive_indicators").$type<string[]>().notNull(),
  limitations: jsonb("limitations").$type<string[]>().notNull(),
  recommendations: jsonb("recommendations").$type<string[]>().notNull(),
  modelVersion: text("model_version").notNull(),
  ruleSetVersion: text("rule_set_version").notNull(),
  status: text("status").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTrustAnalysisSchema = createInsertSchema(trustAnalysesTable).omit({
  id: true,
  createdAt: true,
});

export type InsertTrustAnalysis = z.infer<typeof insertTrustAnalysisSchema>;
export type TrustAnalysis = typeof trustAnalysesTable.$inferSelect;
