import { createInsertSchema } from "drizzle-zod";
import { integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const trustSettingsTable = pgTable("trust_settings", {
  sessionOwner: text("session_owner").primaryKey(),
  retentionDays: integer("retention_days").notNull().default(90),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertTrustSettingsSchema = createInsertSchema(trustSettingsTable).omit({
  createdAt: true,
  updatedAt: true,
});

export type InsertTrustSettings = z.infer<typeof insertTrustSettingsSchema>;
export type TrustSettings = typeof trustSettingsTable.$inferSelect;
