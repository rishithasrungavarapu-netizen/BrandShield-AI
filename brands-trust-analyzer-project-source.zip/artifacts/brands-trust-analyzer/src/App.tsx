import { type FormEvent, type ReactNode, type RefObject, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  getGetTrustReportQueryKey,
  getGetTrustSettingsQueryKey,
  getGetTrustSummaryQueryKey,
  getListTrustReportsQueryKey,
  useAnalyzeTrustTarget,
  useDeleteTrustReport,
  useGetTrustReport,
  useGetTrustSettings,
  useGetTrustSummary,
  useListTrustReports,
  useUpdateTrustSettings,
  type TrustAnalysisInput,
  type TrustFinding,
  type TrustReport,
  type TrustReportSummary,
  type TrustSettingsInputRetentionDays,
} from '@workspace/api-client-react';
import {
  Activity, AlertCircle, ArrowDownToLine, ArrowLeft, ArrowRight,
  BookOpenCheck, Check, ChevronRight, CircleHelp, Clock3, ExternalLink,
  FileSearch, Globe2, Info, Link2, LoaderCircle, LockKeyhole, Plus, Settings2, Shield,
  ShieldAlert, ShieldCheck, Trash2, TriangleAlert,
} from 'lucide-react';
import { Link, Route, Switch, Router as WouterRouter, useLocation, useParams } from 'wouter';

const queryClient = new QueryClient();

function errorText(error: unknown) {
  if (error && typeof error === 'object' && 'message' in error) return String(error.message);
  return 'Something went wrong. Please try again.';
}

const riskLabel = (level: string) => level.replaceAll('_', ' ');
const authenticityLabel = (value: string) => value.replaceAll('_', ' ');
const dateLabel = (value: string) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date);
};

function RiskBadge({ level }: { level: string }) {
  return <span className={`risk-${level} inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold capitalize`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{riskLabel(level)} risk</span>;
}

function SectionLabel({ children }: { children: ReactNode }) {
  return <p className="mono text-[10px] font-medium text-slate-500">{children}</p>;
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const reportsActive = location.startsWith('/reports');
  const settingsActive = location === '/settings';
  return <div className="app-shell flex min-h-[100dvh] text-slate-200">
    <aside className="sidebar flex w-[226px] shrink-0 flex-col border-r border-slate-800/90 px-4 py-5 md:sticky md:top-0 md:h-[100dvh]">
      <Link href="/" className="mb-10 flex items-center gap-3 px-1 no-underline" data-testid="link-home-brand">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-blue-400/25 bg-blue-500/15 text-blue-300"><Shield size={19} strokeWidth={2.2} /></span>
        <span><span className="block font-[Manrope] text-[14px] font-extrabold tracking-tight text-slate-100">BRANDS</span><span className="mono block text-[9px] text-slate-500">TRUST ANALYZER</span></span>
      </Link>
      <SectionLabel>WORKSPACE</SectionLabel>
      <nav className="sidebar-nav mt-3 flex flex-col gap-1.5" aria-label="Main navigation">
        <Link href="/" className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm no-underline transition-colors ${location === '/' ? 'bg-blue-500/15 font-semibold text-blue-300' : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'}`} data-testid="link-analyzer">
          <Activity size={17} /> Analyzer
        </Link>
        <Link href="/reports" className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm no-underline transition-colors ${reportsActive ? 'bg-blue-500/15 font-semibold text-blue-300' : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'}`} data-testid="link-reports">
          <BookOpenCheck size={17} /> Reports
        </Link>
        <Link href="/settings" className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm no-underline transition-colors ${settingsActive ? 'bg-blue-500/15 font-semibold text-blue-300' : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'}`} data-testid="link-settings">
          <Settings2 size={17} /> Settings
        </Link>
      </nav>
      <div className="sidebar-footer mt-auto">
        <div className="mb-4 rounded-xl border border-teal-400/15 bg-teal-400/[.06] p-3.5">
          <div className="mb-2 flex items-center gap-2 text-teal-300"><LockKeyhole size={14} /><span className="mono text-[9px]">EVIDENCE FIRST</span></div>
          <p className="m-0 text-xs leading-5 text-slate-400">Signals are context, not a verdict. Always verify through official channels.</p>
        </div>
        <div className="flex items-center gap-2 border-t border-slate-800 pt-4 text-[11px] text-slate-500"><span className="h-1.5 w-1.5 rounded-full bg-teal-400" />Public-signal workspace</div>
      </div>
    </aside>
    <div className="min-w-0 flex-1">
      <header className="no-print flex h-[62px] items-center justify-between border-b border-slate-800/80 px-5 md:px-9">
        <div className="flex items-center gap-2 text-xs text-slate-500"><span className="mono hidden sm:inline">RISK INTELLIGENCE</span><ChevronRight size={13} className="hidden sm:block" /><span className="capitalize text-slate-300">{location === '/' ? 'Analyzer' : location === '/settings' ? 'Privacy settings' : location.startsWith('/reports/') ? 'Report detail' : 'Saved reports'}</span></div>
        <div className="flex items-center gap-2 rounded-full border border-slate-700/80 px-3 py-1.5 text-[11px] text-slate-400"><span className="h-1.5 w-1.5 rounded-full bg-teal-400" /> Private to this browser</div>
      </header>
      <main className="mx-auto w-full max-w-[1240px] px-4 py-7 md:px-9 md:py-9">{children}</main>
    </div>
  </div>;
}

function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-wrap items-end justify-between gap-5">
    <div><SectionLabel>{eyebrow}</SectionLabel><h1 className="mb-2 mt-2 font-[Manrope] text-3xl font-bold tracking-[-.04em] text-slate-100 md:text-[34px]">{title}</h1><p className="m-0 max-w-2xl text-sm leading-6 text-slate-400">{description}</p></div>{action}
  </div>;
}

function LoadingPanel({ label = 'Loading workspace data' }: { label?: string }) {
  return <div className="panel rounded-xl p-5"><div className="mb-4 flex items-center gap-3"><span className="h-8 w-8 animate-pulse rounded-lg bg-slate-700/60" /><span className="h-3 w-40 animate-pulse rounded bg-slate-700/60" /></div><div className="h-3 w-full animate-pulse rounded bg-slate-800" /><p className="mb-0 mt-4 text-xs text-slate-500">{label}…</p></div>;
}

function QueryError({ message, retry }: { message: string; retry: () => void }) {
  return <div className="rounded-xl border border-rose-400/20 bg-rose-400/[.06] p-5" role="alert"><div className="flex items-start gap-3"><AlertCircle className="mt-0.5 text-rose-300" size={18} /><div className="flex-1"><p className="m-0 text-sm font-semibold text-rose-200">We couldn't load this information</p><p className="mb-3 mt-1 text-xs text-slate-400">{message}</p><button onClick={retry} className="text-xs font-semibold text-rose-200 underline underline-offset-4">Try again</button></div></div></div>;
}

function Metric({ label, value, tone = 'text-slate-100' }: { label: string; value: ReactNode; tone?: string }) {
  return <div className="panel rounded-xl px-4 py-4"><SectionLabel>{label}</SectionLabel><div className={`mt-2 font-[Manrope] text-2xl font-bold ${tone}`}>{value}</div></div>;
}

function SummaryStrip() {
  const query = useGetTrustSummary();
  if (query.isLoading) return <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">{[0,1,2,3,4].map(i => <div key={i} className="panel h-[86px] animate-pulse rounded-xl" />)}</div>;
  if (query.isError) return <QueryError message={errorText(query.error)} retry={() => void query.refetch()} />;
  const summary = query.data;
  if (!summary) return null;
  return <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
    <Metric label="Saved reports" value={summary.total} />
    <Metric label="Low risk" value={summary.low} tone="text-teal-300" />
    <Metric label="Moderate" value={summary.moderate} tone="text-amber-300" />
    <Metric label="High / critical" value={summary.high + summary.critical} tone="text-rose-300" />
    <Metric label="Recent signals" value={summary.recent.length} tone="text-blue-300" />
  </div>;
}

function EvidenceRow({ finding }: { finding: TrustFinding }) {
  const icon = finding.severity === 'critical' || finding.severity === 'high' ? <ShieldAlert size={16} /> : finding.severity === 'warning' ? <TriangleAlert size={16} /> : <Info size={16} />;
  const severityColor = finding.severity === 'critical' || finding.severity === 'high' ? 'text-rose-300' : finding.severity === 'warning' ? 'text-amber-300' : 'text-teal-300';
  return <article className="border-b border-slate-800/80 py-4 last:border-0" data-testid={`finding-${finding.category}-${finding.title}`}>
    <div className="flex items-start gap-3">
      <span className={`mt-0.5 ${severityColor}`}>{icon}</span>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2"><h4 className="m-0 text-sm font-semibold text-slate-200">{finding.title}</h4><span className={`rounded border px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider ${severityColor} border-current/20 bg-current/[.06]`}>{finding.severity}</span></div>
        <p className="mb-0 mt-1.5 text-[13px] leading-5 text-slate-400">{finding.description}</p>
        <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-slate-500"><span className="mono">{finding.category}</span><span className="text-slate-700">/</span><span>{finding.observationType.replaceAll('_', ' ')}</span>
          {finding.sourceUrl && <a href={finding.sourceUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-blue-300 hover:text-blue-200"><ExternalLink size={11} /> Source</a>}
        </div>
      </div>
    </div>
  </article>;
}

function Bullets({ title, items, kind }: { title: string; items: string[]; kind: 'positive' | 'warning' | 'neutral' }) {
  const color = kind === 'positive' ? 'text-teal-300' : kind === 'warning' ? 'text-amber-300' : 'text-blue-300';
  const icon = kind === 'positive' ? <Check size={14} /> : kind === 'warning' ? <TriangleAlert size={14} /> : <CircleHelp size={14} />;
  return <section className="panel rounded-xl p-5">
    <div className="mb-3 flex items-center gap-2"><span className={color}>{icon}</span><h3 className="m-0 text-sm font-semibold text-slate-200">{title}</h3><span className="ml-auto rounded-full bg-slate-800 px-2 py-0.5 text-[10px] text-slate-500">{items.length}</span></div>
    {items.length ? <ul className="m-0 space-y-2 pl-4 text-[13px] leading-5 text-slate-400">{items.map((item, index) => <li key={`${index}-${item}`}>{item}</li>)}</ul> : <p className="m-0 text-xs text-slate-500">No items reported.</p>}
  </section>;
}

function ReportView({ report, compact = false }: { report: TrustReport; compact?: boolean }) {
  const riskTone = report.riskLevel === 'low' ? 'text-teal-300' : report.riskLevel === 'moderate' ? 'text-amber-300' : 'text-rose-300';
  const scoreContributors = report.findings.filter(finding => finding.scoreImpact > 0);
  const findingsBySeverity = [
    { severity: 'critical', title: 'Critical', findings: report.findings.filter(finding => finding.severity === 'critical') },
    { severity: 'high', title: 'High', findings: report.findings.filter(finding => finding.severity === 'high') },
    { severity: 'warning', title: 'Warning', findings: report.findings.filter(finding => finding.severity === 'warning') },
    { severity: 'informational', title: 'Informational', findings: report.findings.filter(finding => finding.severity === 'informational') },
  ].filter(group => group.findings.length > 0);
  return <div className="report-print space-y-4" data-testid={`report-result-${report.id}`}>
    <section className="panel soft-grid overflow-hidden rounded-2xl p-5 md:p-7">
      <div className="flex flex-wrap items-start justify-between gap-5">
        <div className="min-w-0"><div className="mb-3 flex flex-wrap items-center gap-2"><RiskBadge level={report.riskLevel} /><span className="rounded-full border border-slate-700 px-2.5 py-1 text-xs capitalize text-slate-400">{report.status.replaceAll('_', ' ')}</span><span className="rounded-full border border-teal-400/20 bg-teal-400/[.07] px-2.5 py-1 text-xs capitalize text-teal-300">{report.analysisType} analysis</span></div>
          <h2 className="mb-1 break-all font-[Manrope] text-2xl font-bold tracking-tight text-slate-100">{report.domain}</h2>
          <a className="inline-flex max-w-full items-center gap-1.5 break-all text-xs text-blue-300 hover:text-blue-200" href={report.submittedUrl} target="_blank" rel="noreferrer"><Link2 size={12} />{report.submittedUrl}<ExternalLink size={11} /></a>
        </div>
        <div className="flex items-center gap-4 rounded-xl border border-slate-700/70 bg-slate-950/25 px-4 py-3">
          <div className="relative flex h-[62px] w-[62px] items-center justify-center rounded-full border-[5px] border-slate-700 text-lg font-bold text-slate-100" style={{ background: `conic-gradient(${report.riskLevel === 'low' ? '#39c4a7' : report.riskLevel === 'moderate' ? '#deb35c' : '#e27474'} ${report.riskScore * 3.6}deg, transparent 0)` }}>
            <span className="absolute inset-[5px] flex items-center justify-center rounded-full bg-[#111c2d]">{report.riskScore}</span>
          </div><div><SectionLabel>RISK SCORE</SectionLabel><p className={`mb-0 mt-1 text-sm font-semibold capitalize ${riskTone}`}>{riskLabel(report.riskLevel)}</p></div>
        </div>
      </div>
      <div className="mt-5 border-t border-slate-700/70 pt-4"><SectionLabel>ASSESSMENT SUMMARY</SectionLabel><p className="mb-0 mt-2 max-w-4xl text-sm leading-6 text-slate-300">{report.summary}</p></div>
      {!compact && <div className="mt-5 border-t border-slate-700/70 pt-4" data-testid="score-contributors">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div><SectionLabel>SCORE CONTRIBUTORS</SectionLabel><p className="mb-0 mt-1 text-xs leading-5 text-slate-400">Points are rule weights; the total is capped at 100. This score is not a probability.</p></div>
          {scoreContributors.length > 0 && <span className="mono text-[9px] text-slate-500">{scoreContributors.length} weighted signals</span>}
        </div>
        {scoreContributors.length > 0
          ? <ul className="mb-0 mt-3 space-y-2 p-0">
            {scoreContributors.map((finding, index) => <li key={`${finding.category}-${index}`} className="flex items-center justify-between gap-4 border-t border-slate-800/70 pt-2.5 text-xs">
              <span className="min-w-0 text-slate-300">{finding.title}</span>
              <span className="shrink-0 font-mono font-medium text-amber-300">+{finding.scoreImpact} points</span>
            </li>)}
          </ul>
          : <p className="mb-0 mt-3 rounded-lg border border-slate-700/70 bg-slate-950/20 px-3 py-2.5 text-xs text-slate-500">No signals contributed points to this score.</p>}
      </div>}
      {!compact && <div className="mt-5 grid gap-3 border-t border-slate-700/70 pt-4 sm:grid-cols-3">
        <div><SectionLabel>AUTHENTICITY SIGNAL</SectionLabel><p className="mb-0 mt-1.5 text-sm capitalize text-slate-200">{authenticityLabel(report.authenticity)}</p></div>
        <div><SectionLabel>CONFIDENCE</SectionLabel><p className="mb-0 mt-1.5 text-sm capitalize text-slate-200">{report.confidence}</p></div>
        <div><SectionLabel>SNAPSHOT TIME</SectionLabel><p className="mb-0 mt-1.5 text-sm text-slate-200">{dateLabel(report.createdAt)}</p><p className="mb-0 mt-1 text-[10px] text-slate-500">One-time snapshot · not ongoing monitoring</p></div>
      </div>}
    </section>
    {!compact && <>
      <section className="panel rounded-xl px-5 py-2 md:px-6">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 py-4"><div><SectionLabel>EVIDENCE LOG</SectionLabel><p className="mb-0 mt-1 text-sm text-slate-400">Observations are categorized by how they were obtained.</p></div><span className="mono text-[10px] text-slate-500">{report.findings.length} findings</span></div>
        {report.findings.length
          ? <div className="divide-y divide-slate-800/80">
            {findingsBySeverity.map(group => {
              const headingId = `finding-group-${report.id}-${group.severity}`;
              return <section key={group.severity} aria-labelledby={headingId} className="py-3 first:pt-1 last:pb-1">
                <div className="flex items-center justify-between gap-3 py-2">
                  <h3 id={headingId} className="m-0 text-xs font-semibold uppercase tracking-wider text-slate-300">{group.title} findings</h3>
                  <span className="rounded-full border border-slate-700 bg-slate-950/30 px-2 py-0.5 text-[10px] text-slate-400" aria-label={`${group.findings.length} ${group.title.toLowerCase()} findings`}>{group.findings.length}</span>
                </div>
                {group.findings.map((finding, index) => <EvidenceRow key={`${finding.category}-${index}`} finding={finding} />)}
              </section>;
            })}
          </div>
          : <div className="py-8 text-center text-sm text-slate-500">No findings were returned for this assessment.</div>}
      </section>
      <div className="grid gap-4 lg:grid-cols-2">
        <Bullets title="Warning signs" items={report.warningSigns} kind="warning" />
        <Bullets title="Positive indicators" items={report.positiveIndicators} kind="positive" />
        <Bullets title="Limitations" items={report.limitations} kind="neutral" />
        <Bullets title="Recommended next steps" items={report.recommendations} kind="positive" />
      </div>
      <section className="rounded-xl border border-amber-300/20 bg-amber-200/[.05] p-4 md:p-5">
        <div className="flex items-start gap-3"><Info size={17} className="mt-0.5 shrink-0 text-amber-200" /><div><p className="m-0 text-sm font-semibold text-amber-100">Use this report as a starting point—not a verdict.</p><p className="mb-0 mt-1 text-xs leading-5 text-slate-400">This analysis reflects available public signals at the time it was generated. It does not establish intent, identity, or wrongdoing. Confirm important claims directly with the brand using independently verified contact details.</p></div></div>
      </section>
      <div className="flex flex-wrap gap-x-5 gap-y-2 px-1 text-[10px] text-slate-500"><span>Model: {report.modelVersion}</span><span>Rule set: {report.ruleSetVersion}</span><span>AI-assisted: {report.hasAi ? 'Yes' : 'No'}</span></div>
    </>}
  </div>;
}

function AnalysisForm({ onReport, targetInputRef }: { onReport: (report: TrustReport) => void; targetInputRef: RefObject<HTMLInputElement | null> }) {
  const [mode, setMode] = useState<'website' | 'account'>('website');
  const [url, setUrl] = useState('');
  const [claimedBrand, setClaimedBrand] = useState('');
  const [officialWebsite, setOfficialWebsite] = useState('');
  const [publicEvidence, setPublicEvidence] = useState('');
  const mutation = useAnalyzeTrustTarget();
  const cache = useQueryClient();
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const input: TrustAnalysisInput = { url: url.trim(), mode };
    if (claimedBrand.trim()) input.claimedBrand = claimedBrand.trim();
    if (officialWebsite.trim()) input.officialWebsite = officialWebsite.trim();
    if (publicEvidence.trim()) input.publicEvidence = publicEvidence.trim();
    mutation.mutate({ data: input }, {
      onSuccess: report => {
        onReport(report);
        void cache.invalidateQueries({ queryKey: getListTrustReportsQueryKey() });
        void cache.invalidateQueries({ queryKey: getGetTrustSummaryQueryKey() });
        void cache.invalidateQueries({ queryKey: getGetTrustReportQueryKey(report.id) });
      },
    });
  };
  return <form onSubmit={submit} className="panel rounded-2xl p-5 md:p-6">
    <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
      <div><SectionLabel>START AN ASSESSMENT</SectionLabel><h2 className="mb-0 mt-1.5 text-lg font-semibold text-slate-100">What should we examine?</h2></div>
      <div className="flex rounded-lg border border-slate-700 bg-slate-950/30 p-1" role="group" aria-label="Analysis mode">
        <button type="button" onClick={() => setMode('website')} aria-pressed={mode === 'website'} className={`flex items-center gap-2 rounded-md px-3 py-2 text-xs font-semibold transition-colors ${mode === 'website' ? 'bg-blue-500 text-white' : 'text-slate-400 hover:text-slate-200'}`} data-testid="button-mode-website"><Globe2 size={14} /> Website</button>
        <button type="button" onClick={() => setMode('account')} aria-pressed={mode === 'account'} className={`flex items-center gap-2 rounded-md px-3 py-2 text-xs font-semibold transition-colors ${mode === 'account' ? 'bg-blue-500 text-white' : 'text-slate-400 hover:text-slate-200'}`} data-testid="button-mode-account"><Activity size={14} /> Public account</button>
      </div>
    </div>
    {mode === 'account' && <div className="mb-4 flex items-start gap-2.5 rounded-lg border border-sky-300/15 bg-sky-300/[.05] p-3 text-xs leading-5 text-sky-100/80"><Info size={15} className="mt-0.5 shrink-0 text-sky-300" /><p className="m-0"><strong className="font-semibold text-sky-200">Platform access may be limited.</strong> We assess only the submitted profile URL and public evidence you provide; we do not sign in to or access private platform data.</p></div>}
    <div className="mb-4 flex items-start gap-2.5 rounded-lg border border-teal-300/15 bg-teal-300/[.04] p-3 text-xs leading-5 text-slate-400">
      <LockKeyhole size={15} className="mt-0.5 shrink-0 text-teal-300" />
      <p className="m-0"><strong className="font-semibold text-slate-200">AI &amp; data use.</strong> When AI is configured, a short sanitized page-text excerpt plus the evidence/signals you supply is sent to OpenAI to generate the explanation. No account passwords or private profile data are fetched. Reports without AI are rule-based. No login or account is created.</p>
    </div>
    <label htmlFor="target-url" className="mb-1.5 block text-xs font-medium text-slate-300">{mode === 'website' ? 'Website URL' : 'Public profile URL'} <span className="text-rose-300">*</span></label>
    <div className="flex flex-col gap-2 sm:flex-row"><div className="relative min-w-0 flex-1"><Globe2 size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" /><input ref={targetInputRef} id="target-url" required type="url" maxLength={2048} placeholder={mode === 'website' ? 'https://example.com' : 'https://social.example/brand'} value={url} onChange={e => setUrl(e.target.value)} className="h-12 w-full rounded-lg border border-slate-700 bg-slate-950/40 pl-10 pr-3 text-sm text-slate-100 placeholder:text-slate-600" data-testid="input-target-url" /></div><button disabled={mutation.isPending} type="submit" className="flex h-12 shrink-0 items-center justify-center gap-2 rounded-lg bg-blue-500 px-5 text-sm font-semibold text-white transition-colors hover:bg-blue-400 disabled:cursor-wait disabled:opacity-70" data-testid="button-analyze">{mutation.isPending ? <><LoaderCircle size={16} className="animate-spin" /> Assessing</> : <>Analyze target <ArrowRight size={16} /></>}</button></div>
    <div className="mt-4 grid gap-3 sm:grid-cols-2">
      <div><label htmlFor="claimed-brand" className="mb-1.5 block text-xs font-medium text-slate-400">Claimed brand <span className="font-normal text-slate-600">optional</span></label><input id="claimed-brand" maxLength={120} value={claimedBrand} onChange={e => setClaimedBrand(e.target.value)} placeholder="Brand or organization name" className="h-10 w-full rounded-lg border border-slate-700 bg-slate-950/30 px-3 text-sm text-slate-200 placeholder:text-slate-600" data-testid="input-claimed-brand" /></div>
      <div><label htmlFor="official-website" className="mb-1.5 block text-xs font-medium text-slate-400">Official website <span className="font-normal text-slate-600">optional reference</span></label><input id="official-website" type="url" maxLength={2048} value={officialWebsite} onChange={e => setOfficialWebsite(e.target.value)} placeholder="https://official-brand.com" className="h-10 w-full rounded-lg border border-slate-700 bg-slate-950/30 px-3 text-sm text-slate-200 placeholder:text-slate-600" data-testid="input-official-website" /></div>
    </div>
    <div className="mt-3"><label htmlFor="public-evidence" className="mb-1.5 block text-xs font-medium text-slate-400">Public evidence or context <span className="font-normal text-slate-600">optional</span></label><textarea id="public-evidence" maxLength={5000} rows={3} value={publicEvidence} onChange={e => setPublicEvidence(e.target.value)} placeholder="Share publicly available context or specific claims you'd like considered…" className="w-full resize-y rounded-lg border border-slate-700 bg-slate-950/30 px-3 py-2.5 text-sm leading-5 text-slate-200 placeholder:text-slate-600" data-testid="input-public-evidence" /><div className="mt-1 text-right text-[10px] text-slate-600">{publicEvidence.length}/5000</div></div>
    {mutation.isError && <div className="mt-4" role="alert"><QueryError message={errorText(mutation.error)} retry={() => mutation.mutate({ data: { url: url.trim(), mode, ...(claimedBrand.trim() ? { claimedBrand: claimedBrand.trim() } : {}), ...(officialWebsite.trim() ? { officialWebsite: officialWebsite.trim() } : {}), ...(publicEvidence.trim() ? { publicEvidence: publicEvidence.trim() } : {}) } }, { onSuccess: report => { onReport(report); void cache.invalidateQueries({ queryKey: getListTrustReportsQueryKey() }); void cache.invalidateQueries({ queryKey: getGetTrustSummaryQueryKey() }); void cache.invalidateQueries({ queryKey: getGetTrustReportQueryKey(report.id) }); } })} /></div>}
    <div className="mt-4 flex items-start gap-2 border-t border-slate-800 pt-3 text-[11px] leading-5 text-slate-500"><LockKeyhole size={13} className="mt-0.5 shrink-0 text-teal-400" /><span>Analysis uses public information and the context you submit. A risk score is not proof of fraud or endorsement.</span></div>
  </form>;
}

function RecentReports() {
  const query = useListTrustReports({ limit: 5 });
  if (query.isLoading) return <LoadingPanel label="Loading recent reports" />;
  if (query.isError) return <QueryError message={errorText(query.error)} retry={() => void query.refetch()} />;
  const reports = query.data ?? [];
  return <section className="panel rounded-2xl">
    <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4"><div><SectionLabel>RECENT REPORTS</SectionLabel><h2 className="mb-0 mt-1 text-sm font-semibold text-slate-200">Recent reports</h2></div><Link href="/reports" className="inline-flex items-center gap-1 text-xs font-medium text-blue-300 no-underline hover:text-blue-200" data-testid="link-all-reports">View all <ArrowRight size={13} /></Link></div>
    {reports.length ? <div>{reports.slice(0,5).map((report, index) => <ReportListRow key={report.id} report={report} index={index} compact />)}</div> : <div className="px-5 py-8 text-center"><div className="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-full border border-slate-700 bg-slate-800/60 text-slate-400"><FileSearch size={18} /></div><p className="mb-1 text-sm font-medium text-slate-300">No reports yet</p><p className="m-0 text-xs text-slate-500">Your saved analysis reports will appear here.</p></div>}
  </section>;
}

function ReportListRow({ report, index, compact = false, onDelete }: { report: TrustReportSummary; index: number; compact?: boolean; onDelete?: (id: string) => void }) {
  return <div className={`group flex items-center gap-3 px-5 py-4 transition-colors hover:bg-slate-800/25 ${index ? 'border-t border-slate-800/70' : ''}`} data-testid={`row-report-${report.id}`}>
    <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border ${report.riskLevel === 'low' ? 'border-teal-300/15 bg-teal-300/[.06] text-teal-300' : report.riskLevel === 'moderate' ? 'border-amber-300/15 bg-amber-300/[.06] text-amber-300' : 'border-rose-300/15 bg-rose-300/[.06] text-rose-300'}`}>{report.analysisType === 'website' ? <Globe2 size={16} /> : <Activity size={16} />}</span>
    <div className="min-w-0 flex-1"><Link href={`/reports/${encodeURIComponent(report.id)}`} className="block truncate text-sm font-semibold text-slate-200 no-underline hover:text-blue-300" data-testid={`link-report-${report.id}`}>{report.domain}</Link><p className="mb-0 mt-1 truncate text-[11px] text-slate-500">{report.summary}</p><div className="mt-1.5 flex items-center gap-2 text-[10px] text-slate-600"><span className="capitalize">{report.analysisType}</span><span>·</span><Clock3 size={10} /><span>{dateLabel(report.createdAt)}</span></div></div>
    <div className="flex shrink-0 flex-col items-end gap-1.5"><RiskBadge level={report.riskLevel} /><span className="mono text-[9px] text-slate-500">SCORE {report.riskScore}</span></div>
    {!compact && onDelete && <button aria-label={`Delete report for ${report.domain}`} title="Delete report" onClick={() => onDelete(report.id)} className="ml-1 rounded-md p-2 text-slate-600 transition-colors hover:bg-rose-400/10 hover:text-rose-300" data-testid={`button-delete-${report.id}`}><Trash2 size={15} /></button>}
  </div>;
}

function HomePage() {
  const [result, setResult] = useState<TrustReport | null>(null);
  const [formKey, setFormKey] = useState(0);
  const targetInputRef = useRef<HTMLInputElement>(null);
  const focusAfterReset = useRef(false);
  useEffect(() => {
    if (focusAfterReset.current) {
      focusAfterReset.current = false;
      targetInputRef.current?.focus();
    }
  }, [formKey]);
  const analyzeAnother = () => {
    focusAfterReset.current = true;
    setResult(null);
    setFormKey((current) => current + 1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  return <div className="enter space-y-7">
    <PageHeading eyebrow="PUBLIC SIGNAL REVIEW / 01" title="Trust, with evidence." description="Assess a website or public profile through observable signals. Get clear findings, their sources, and the limits of what can be concluded." />
    <SummaryStrip />
    <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1.25fr)_minmax(340px,.75fr)]">
      <AnalysisForm key={formKey} onReport={setResult} targetInputRef={targetInputRef} />
      <RecentReports />
    </div>
    {result && <section className="enter space-y-4 pt-2" aria-live="polite"><div className="flex flex-wrap items-end justify-between gap-3"><div><SectionLabel>ASSESSMENT COMPLETE</SectionLabel><h2 className="mb-0 mt-1.5 font-[Manrope] text-xl font-bold text-slate-100">Your evidence report</h2></div><div className="no-print flex items-center gap-3"><button type="button" onClick={analyzeAnother} className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-300 transition-colors hover:text-white" data-testid="button-analyze-another"><Plus size={14} /> Analyze another</button><Link href={`/reports/${encodeURIComponent(result.id)}`} className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-300 no-underline hover:text-blue-200" data-testid="link-open-full-report">Full report <ArrowRight size={14} /></Link></div></div><ReportView report={result} compact={false} /></section>}
    <div className="flex items-start gap-2 border-t border-slate-800/80 pt-4 text-[11px] leading-5 text-slate-500"><ShieldCheck size={14} className="mt-0.5 shrink-0 text-teal-400" /><p className="m-0">Brands Trust Analyzer is an evidence-first tool. Scores indicate patterns in available public data and must not be treated as a determination that an individual or organization is fraudulent.</p></div>
  </div>;
}

function ReportsPage() {
  const query = useListTrustReports();
  const deletion = useDeleteTrustReport();
  const cache = useQueryClient();
  const remove = (id: string) => {
    if (!window.confirm('Delete this saved report from this browser? This cannot be undone.')) return;
    deletion.mutate({ id }, { onSuccess: () => {
      void cache.invalidateQueries({ queryKey: getListTrustReportsQueryKey() });
      void cache.invalidateQueries({ queryKey: getGetTrustSummaryQueryKey() });
      void cache.invalidateQueries({ queryKey: getGetTrustReportQueryKey(id) });
    } });
  };
  return <div className="enter">
    <PageHeading eyebrow="BROWSER ARCHIVE / 02" title="Saved reports" description="Review reports saved privately to this browser. They do not sync across browsers or devices, and can be removed at any time." action={<Link href="/" className="inline-flex items-center gap-2 rounded-lg bg-blue-500 px-4 py-2.5 text-sm font-semibold text-white no-underline hover:bg-blue-400" data-testid="link-new-analysis"><Plus size={16} /> New analysis</Link>} />
    <SummaryStrip />
    <section className="panel mt-6 overflow-hidden rounded-2xl">
      <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4"><div><SectionLabel>ALL ANALYSES</SectionLabel><h2 className="mb-0 mt-1 text-sm font-semibold text-slate-200">{query.data?.length ?? '—'} reports</h2></div><span className="inline-flex items-center gap-1.5 text-[10px] text-slate-500"><LockKeyhole size={11} /> This browser only</span></div>
      {query.isLoading && <div className="space-y-3 p-5">{[0,1,2].map(i => <div key={i} className="h-[66px] animate-pulse rounded-lg bg-slate-800/50" />)}</div>}
      {query.isError && <div className="p-5"><QueryError message={errorText(query.error)} retry={() => void query.refetch()} /></div>}
      {!query.isLoading && !query.isError && (query.data?.length ?? 0) === 0 && <div className="px-5 py-16 text-center"><div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl border border-slate-700 bg-slate-800/50 text-slate-400"><FileSearch size={21} /></div><h3 className="mb-1 text-sm font-semibold text-slate-200">Your archive is clear</h3><p className="mx-auto mb-5 max-w-sm text-xs leading-5 text-slate-500">Complete an assessment and its report will be saved privately to this browser.</p><Link href="/" className="inline-flex items-center gap-2 rounded-lg bg-blue-500 px-4 py-2.5 text-xs font-semibold text-white no-underline hover:bg-blue-400" data-testid="link-start-first-analysis">Start an analysis <ArrowRight size={14} /></Link></div>}
      {query.data && query.data.length > 0 && query.data.map((report, index) => <ReportListRow key={report.id} report={report} index={index} onDelete={remove} />)}
      {deletion.isError && <div className="m-4 rounded-lg border border-rose-400/20 bg-rose-400/[.06] p-3 text-xs text-rose-200" role="alert">Could not delete this report: {errorText(deletion.error)}. Please try again.</div>}
    </section>
  </div>;
}

function ReportDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params.id ?? '';
  const query = useGetTrustReport(id, { query: { enabled: !!id, queryKey: getGetTrustReportQueryKey(id) } });
  const deletion = useDeleteTrustReport();
  const cache = useQueryClient();
  const [, setLocation] = useLocation();
  const remove = () => {
    if (!window.confirm('Delete this report from this browser? This cannot be undone.')) return;
    deletion.mutate({ id }, { onSuccess: () => {
      void cache.invalidateQueries({ queryKey: getListTrustReportsQueryKey() });
      void cache.invalidateQueries({ queryKey: getGetTrustSummaryQueryKey() });
      void cache.invalidateQueries({ queryKey: getGetTrustReportQueryKey(id) });
      setLocation('/reports');
    } });
  };
  return <div className="enter">
    <div className="no-print mb-6 flex flex-wrap items-center justify-between gap-3">
      <Link href="/reports" className="inline-flex items-center gap-2 text-xs font-medium text-slate-400 no-underline hover:text-slate-200" data-testid="link-back-reports"><ArrowLeft size={15} /> Back to reports</Link>
      <div className="flex gap-2">
        <button onClick={() => window.print()} disabled={!query.data} className="inline-flex items-center gap-2 rounded-lg border border-slate-700 px-3 py-2 text-xs font-semibold text-slate-300 hover:border-slate-500 hover:bg-slate-800 disabled:opacity-50" data-testid="button-download-pdf"><ArrowDownToLine size={14} /> Download PDF</button>
        {query.data && <button onClick={remove} className="inline-flex items-center gap-2 rounded-lg border border-rose-300/20 px-3 py-2 text-xs font-semibold text-rose-300 hover:bg-rose-400/10" data-testid="button-delete-report"><Trash2 size={14} /> Delete</button>}
      </div>
    </div>
    {query.isLoading && <div className="space-y-4"><div className="panel h-56 animate-pulse rounded-2xl" /><div className="panel h-64 animate-pulse rounded-xl" /></div>}
    {query.isError && <div><PageHeading eyebrow="REPORT DETAIL" title="Report unavailable" description="We couldn't retrieve this report saved to this browser." /><QueryError message={errorText(query.error)} retry={() => void query.refetch()} /><Link href="/reports" className="mt-4 inline-flex items-center gap-2 text-sm text-blue-300 no-underline"><ArrowLeft size={15} /> Return to reports</Link></div>}
    {query.data && <><PageHeading eyebrow={`REPORT / ${query.data.id}`} title="Evidence report" description="Review each observation in context. Source links and collection limitations are part of the assessment." /><ReportView report={query.data} />{deletion.isError && <p className="mt-3 text-xs text-rose-300" role="alert">Delete failed: {errorText(deletion.error)}</p>}</>}
  </div>;
}

const retentionChoices: { days: TrustSettingsInputRetentionDays; title: string; detail: string }[] = [
  { days: 7, title: '7 days', detail: 'Brief review window' },
  { days: 30, title: '30 days', detail: 'A balanced default' },
  { days: 90, title: '90 days', detail: 'Quarterly review' },
  { days: 180, title: '180 days', detail: 'Extended monitoring' },
  { days: 365, title: '365 days', detail: 'Full-year history' },
];

function SettingsPage() {
  const query = useGetTrustSettings();
  const update = useUpdateTrustSettings();
  const cache = useQueryClient();
  const [selectedDays, setSelectedDays] = useState<TrustSettingsInputRetentionDays | null>(null);
  const [confirmingShorter, setConfirmingShorter] = useState(false);
  const [shorterConfirmed, setShorterConfirmed] = useState(false);
  const [saved, setSaved] = useState(false);

  if (query.isLoading) {
    return <div className="enter space-y-5"><PageHeading eyebrow="BROWSER PRIVACY / 03" title="Privacy settings" description="Choose how long analysis reports remain available to this browser." /><div className="panel h-40 animate-pulse rounded-2xl" /><div className="panel h-64 animate-pulse rounded-2xl" /></div>;
  }
  if (query.isError || !query.data) {
    return <div className="enter"><PageHeading eyebrow="BROWSER PRIVACY / 03" title="Privacy settings" description="Choose how long analysis reports remain available to this browser." /><QueryError message={query.isError ? errorText(query.error) : 'Settings are not available right now.'} retry={() => void query.refetch()} /></div>;
  }

  const currentDays = query.data.retentionDays;
  const effectiveDays = selectedDays ?? currentDays;
  const isShorter = effectiveDays < currentDays;
  const changed = effectiveDays !== currentDays;
  const persistSettings = () => {
    if (!changed) return;
    if (isShorter && !confirmingShorter) {
      setConfirmingShorter(true);
      setShorterConfirmed(false);
      return;
    }
    if (isShorter && !shorterConfirmed) return;
    update.mutate({ data: { retentionDays: effectiveDays } }, {
      onSuccess: result => {
        setSelectedDays(result.retentionDays);
        cache.setQueryData(getGetTrustSettingsQueryKey(), result);
        setConfirmingShorter(false);
        setShorterConfirmed(false);
        setSaved(true);
        void cache.invalidateQueries({ queryKey: getGetTrustSettingsQueryKey() });
        void cache.invalidateQueries({ queryKey: getListTrustReportsQueryKey() });
        void cache.invalidateQueries({ queryKey: getGetTrustSummaryQueryKey() });
      },
    });
  };

  return <div className="enter">
    <PageHeading eyebrow="BROWSER PRIVACY / 03" title="Privacy settings" description="Control how long your reports remain available to this browser." />
    <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
      <section className="panel overflow-hidden rounded-2xl">
        <div className="flex items-start gap-3 border-b border-slate-800 px-5 py-5 md:px-6">
          <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-teal-300/20 bg-teal-300/[.07] text-teal-300"><LockKeyhole size={17} /></span>
          <div><SectionLabel>BROWSER DATA</SectionLabel><h2 className="mb-1 mt-1 text-base font-semibold text-slate-100">Report retention</h2><p className="m-0 max-w-xl text-xs leading-5 text-slate-400">Reports are private to this browser and do not sync across browsers or devices. A signed HttpOnly browser cookie can persist for up to one year, so access is not limited to the current tab or browser session. Set a retention period that works for your review workflow.</p></div>
        </div>
        <div className="p-5 md:p-6">
          <fieldset className="m-0 border-0 p-0">
            <legend className="mb-3 text-xs font-semibold text-slate-300">Keep reports for</legend>
            <div className="grid gap-2 sm:grid-cols-2">
              {retentionChoices.map(choice => {
                const checked = effectiveDays === choice.days;
                return <label key={choice.days} className={`flex cursor-pointer items-center gap-3 rounded-xl border px-4 py-3 transition-colors ${checked ? 'border-blue-400/45 bg-blue-400/[.08]' : 'border-slate-700/80 bg-slate-950/20 hover:border-slate-600'}`}>
                  <input type="radio" name="retention-days" value={choice.days} checked={checked} onChange={() => { setSelectedDays(choice.days); setConfirmingShorter(false); setShorterConfirmed(false); setSaved(false); }} className="h-4 w-4 accent-blue-500" data-testid={`radio-retention-${choice.days}`} />
                  <span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-slate-200">{choice.title}</span><span className="mt-0.5 block text-[11px] text-slate-500">{choice.detail}</span></span>
                  {currentDays === choice.days && <span className="rounded-full border border-teal-300/20 bg-teal-300/[.06] px-2 py-1 text-[9px] font-semibold uppercase tracking-wide text-teal-300">Current</span>}
                </label>;
              })}
            </div>
          </fieldset>
          <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800 pt-4">
            <p className="m-0 text-xs text-slate-400">Current retention: <strong className="font-semibold text-slate-200">{currentDays} days</strong></p>
            <button type="button" onClick={persistSettings} disabled={!changed || update.isPending} className="inline-flex items-center justify-center gap-2 rounded-lg bg-blue-500 px-4 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-blue-400 disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-save-retention">
              {update.isPending ? <><LoaderCircle size={14} className="animate-spin" /> Saving</> : isShorter && !confirmingShorter ? 'Review shorter period' : 'Save retention'}
            </button>
          </div>
          {confirmingShorter && isShorter && <div className="mt-4 rounded-xl border border-amber-300/25 bg-amber-200/[.05] p-4" role="alert" aria-labelledby="retention-warning-title">
            <div className="flex items-start gap-3"><TriangleAlert size={17} className="mt-0.5 shrink-0 text-amber-300" /><div className="min-w-0 flex-1">
              <h3 id="retention-warning-title" className="m-0 text-sm font-semibold text-amber-100">Shortening retention permanently removes older reports</h3>
              <p className="mb-3 mt-1.5 text-xs leading-5 text-slate-300">Saving {effectiveDays} days will immediately and permanently delete saved reports older than {effectiveDays} days. This cannot be undone.</p>
              <label className="flex cursor-pointer items-start gap-2 text-xs leading-5 text-slate-300">
                <input type="checkbox" checked={shorterConfirmed} onChange={event => setShorterConfirmed(event.target.checked)} className="mt-0.5 h-4 w-4 shrink-0 accent-amber-400" data-testid="checkbox-confirm-retention-delete" />
                <span>I understand that older reports will be permanently deleted.</span>
              </label>
              <div className="mt-4 flex flex-wrap gap-2">
                <button type="button" onClick={persistSettings} disabled={!shorterConfirmed || update.isPending} className="inline-flex items-center gap-2 rounded-lg border border-amber-300/30 bg-amber-200/10 px-3 py-2 text-xs font-semibold text-amber-100 hover:bg-amber-200/15 disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-confirm-shorter-retention">{update.isPending ? 'Applying…' : 'Confirm and apply shorter retention'}</button>
                <button type="button" onClick={() => { setConfirmingShorter(false); setShorterConfirmed(false); }} className="rounded-lg px-3 py-2 text-xs font-medium text-slate-400 hover:bg-slate-800 hover:text-slate-200" data-testid="button-cancel-retention">Cancel</button>
              </div>
            </div></div>
          </div>}
          {update.isError && <p className="mb-0 mt-4 text-xs text-rose-300" role="alert">Settings could not be saved: {errorText(update.error)}. Your current retention is unchanged.</p>}
          {saved && <p className="mb-0 mt-4 flex items-center gap-2 text-xs text-teal-300" role="status"><ShieldCheck size={14} /> Retention preference saved: {currentDays} days.</p>}
        </div>
      </section>
      <aside className="space-y-4">
        <section className="panel rounded-2xl p-5">
          <div className="mb-3 flex items-center gap-2 text-teal-300"><ShieldCheck size={16} /><SectionLabel>YOUR CONTROL</SectionLabel></div>
          <h2 className="mb-2 mt-0 text-sm font-semibold text-slate-200">Browser privacy</h2>
          <p className="m-0 text-xs leading-5 text-slate-400">Your reports are private to this browser and are not shared across browsers or devices. No login or account is created. Shorter retention limits how long past assessments remain available here.</p>
        </section>
        <section className="rounded-xl border border-slate-700/80 bg-slate-950/20 p-4">
          <div className="mb-2 flex items-center gap-2 text-slate-300"><Info size={14} /><span className="mono text-[9px] text-slate-400">BEFORE YOU CHANGE IT</span></div>
          <p className="m-0 text-[11px] leading-5 text-slate-500">Changing retention does not alter the analysis itself. Reports beyond the selected period are removed by the service when the shorter setting is applied.</p>
        </section>
      </aside>
    </div>
  </div>;
}

function Router() {
  return <RoutedErrorBoundary><Shell><Switch>
    <Route path="/" component={HomePage} />
    <Route path="/reports" component={ReportsPage} />
    <Route path="/reports/:id" component={ReportDetailPage} />
    <Route path="/settings" component={SettingsPage} />
    <Route component={NotFound} />
  </Switch></Shell></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;
