# Brands Trust Analyzer

This is a standalone implementation inspired by the supplied Brands page reference. It is not installed into the reference site's code because that site's source was not available in this workspace.

## Run and configure

- The web app calls the workspace API server and uses the existing PostgreSQL database.
- `OPENAI_API_KEY` is optional. When present, it is read only by the API server and used to explain collected evidence. OpenAI bills model requests to the account that owns that key.
- `OPENAI_MODEL` optionally selects an OpenAI model; the default is `gpt-5.4-mini`.
- Without a working OpenAI key, reports are explicitly marked as basic/rule-based. If the configured service errors, the report says the AI explanation was unavailable.
- `SESSION_SECRET` signs the private, browser-specific report cookie. It is required for saving and reading reports; it is not sent to the browser.
- `TRUST_ANALYSIS_RETENTION_DAYS` sets the initial retention choice for a browser session. Supported defaults are `7`, `30`, `90`, `180`, and `365` days. Users can change this later in **Settings**; choosing a shorter period immediately removes older reports.
- Database schema changes are managed by the existing workspace Drizzle setup.

## What the app checks

Website mode safely retrieves a bounded public text page and evaluates HTTPS, redirects, domain formatting, visible requests for credentials or unusual payment methods, claimed-brand/hostname mismatches, selected external links, and visible contact information. It does not execute page code or open links found on the page. The score is rule-based and is not a probability.

The current weighted rules are: HTTP rather than HTTPS `+10`; redirects `+3` per hop (capped at `+12`) and a cross-domain redirect `+4`; encoded internationalized hostname `+10`; more than five hostname labels `+5`; password or one-time-code request `+20`; unusual/hard-to-reverse payment language `+12`; claimed-brand/hostname mismatch `+20`; selected unusual external sign-in/payment link `+10`; mismatch with a user-supplied official website `+15`; and profile-URL/claimed-brand mismatch `+15`. The total is capped at 100. Missing evidence, missing contact details, and unknown domain age add no risk points. Informational observations add zero points.

Public-account mode accepts a profile URL and optional evidence text. No social-platform API is connected, and the profile page is not fetched. Account age, posting patterns, follower counts, badges, and profile links are not independently verified. Supplied evidence is explicitly treated as unverified.

No WHOIS/domain-age or third-party threat-intelligence service is configured. Those findings are reported as limitations, not silently simulated. The app does not call Gemini or any social platform.

Reports are scoped to a signed, HttpOnly browser cookie rather than a user login. They do not sync across browsers or devices. Users can delete individual reports or apply a shorter retention period in Settings.

## Sample cases and accuracy

Synthetic, inert cases are in `artifacts/api-server/test/fixtures/trust-cases.json`. They cover benign-looking sites, phishing-style requests, identity mismatches, new domains without age evidence, suspicious and inconclusive account evidence, unavailable sites, and a private-address redirect that must be blocked.

The cases are not a representative ground-truth dataset and are not production accuracy measurements. False-positive and false-negative rates have not been measured. A meaningful rate requires a diverse, independently labeled dataset and a test harness that runs the same production scoring rules against the labels. Do not use these fixtures to claim accuracy.
