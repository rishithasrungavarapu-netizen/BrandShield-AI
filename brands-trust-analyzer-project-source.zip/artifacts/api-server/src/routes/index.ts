import { Router, type IRouter } from "express";
import healthRouter from "./health";
import trustRouter from "./trust";

const router: IRouter = Router();

router.use(healthRouter);
router.use(trustRouter);

export default router;
