import { lookup } from "node:dns/promises";
import { request as httpRequest } from "node:http";
import { request as httpsRequest } from "node:https";
import { checkServerIdentity } from "node:tls";
import ipaddr from "ipaddr.js";

const MAX_RESPONSE_BYTES = 1_000_000;
const REQUEST_TIMEOUT_MS = 9_000;
const DNS_TIMEOUT_MS = 3_000;
const MAX_REDIRECTS = 5;
const ALLOWED_CONTENT_TYPES = new Set([
  "text/html",
  "application/xhtml+xml",
  "text/plain",
]);

export type PublicPage = {
  requestedUrl: string;
  finalUrl: string;
  statusCode: number;
  contentType: string;
  body: string;
  redirects: string[];
};

export class SafeFetchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SafeFetchError";
  }
}

export function normalizePublicUrl(input: string): URL {
  const trimmed = input.trim();
  const candidate = /^[a-z][a-z\d+.-]*:\/\//i.test(trimmed)
    ? trimmed
    : `https://${trimmed}`;

  let url: URL;
  try {
    url = new URL(candidate);
  } catch {
    throw new SafeFetchError("Enter a valid public website or profile URL.");
  }

  if (!["http:", "https:"].includes(url.protocol)) {
    throw new SafeFetchError("Only public HTTP or HTTPS URLs can be analyzed.");
  }
  if (url.username || url.password) {
    throw new SafeFetchError("URLs containing usernames or passwords are not accepted.");
  }
  if (url.port && url.port !== (url.protocol === "https:" ? "443" : "80")) {
    throw new SafeFetchError("Non-standard website ports are not accepted.");
  }
  if (!url.hostname || url.hostname.length > 253) {
    throw new SafeFetchError("Enter a valid public domain name.");
  }

  const hostname = url.hostname.toLowerCase().replace(/\.$/, "");
  if (
    hostname === "localhost" ||
    hostname.endsWith(".localhost") ||
    hostname.endsWith(".local") ||
    hostname.endsWith(".internal") ||
    hostname.endsWith(".home") ||
    hostname.endsWith(".lan") ||
    hostname.endsWith(".test") ||
    hostname.endsWith(".invalid") ||
    hostname.endsWith(".example") ||
    hostname.endsWith(".onion")
  ) {
    throw new SafeFetchError("Private, local, or reserved hostnames cannot be analyzed.");
  }

  if (ipaddr.isValid(hostname)) {
    throw new SafeFetchError("Enter a public domain name rather than an IP address.");
  }

  url.hash = "";
  url.hostname = hostname;
  return url;
}

function isPublicAddress(address: string): boolean {
  try {
    const parsed = ipaddr.parse(address);
    return parsed.range() === "unicast";
  } catch {
    return false;
  }
}

async function resolvePublicAddresses(hostname: string) {
  let records: Array<{ address: string; family: number }>;
  try {
    records = await new Promise((resolve, reject) => {
      const timer = setTimeout(
        () => reject(new SafeFetchError("The website domain lookup timed out.")),
        DNS_TIMEOUT_MS,
      );
      lookup(hostname, { all: true, verbatim: true }).then(
        (result) => {
          clearTimeout(timer);
          resolve(result);
        },
        () => {
          clearTimeout(timer);
          reject(new SafeFetchError("The website domain could not be resolved."));
        },
      );
    });
  } catch {
    throw new SafeFetchError("The website domain could not be resolved.");
  }
  if (records.length === 0 || records.some((record) => !isPublicAddress(record.address))) {
    throw new SafeFetchError("The domain resolves to a private or reserved network address.");
  }
  return records;
}

type HopResponse = {
  statusCode: number;
  location: string | undefined;
  contentType: string;
  body: string;
};

function requestPinnedToAddress(url: URL, address: string, family: number): Promise<HopResponse> {
  return new Promise((resolve, reject) => {
    const requestFn = url.protocol === "https:" ? httpsRequest : httpRequest;
    const request = requestFn(
      {
        protocol: url.protocol,
        hostname: address,
        family,
        port: url.protocol === "https:" ? 443 : 80,
        path: `${url.pathname}${url.search}`,
        method: "GET",
        headers: {
          Host: url.hostname,
          "User-Agent": "BrandsTrustAnalyzer/1.0 (public website checks)",
          Accept: "text/html,application/xhtml+xml,text/plain;q=0.8",
          "Accept-Encoding": "identity",
          Connection: "close",
        },
        ...(url.protocol === "https:"
          ? {
              servername: url.hostname,
              checkServerIdentity: (_host: string, certificate: Parameters<typeof checkServerIdentity>[1]) =>
                checkServerIdentity(url.hostname, certificate),
            }
          : {}),
      },
      (response) => {
        const statusCode = response.statusCode ?? 0;
        const contentType = String(response.headers["content-type"] ?? "")
          .split(";", 1)[0]
          .trim()
          .toLowerCase();
        const chunks: Buffer[] = [];
        let bytes = 0;

        if (
          ![301, 302, 303, 307, 308].includes(statusCode) &&
          !ALLOWED_CONTENT_TYPES.has(contentType)
        ) {
          response.destroy();
          request.destroy();
          reject(new SafeFetchError("The website does not serve a supported text page."));
          return;
        }

        const declaredLength = Number(response.headers["content-length"] ?? 0);
        if (declaredLength > MAX_RESPONSE_BYTES) {
          response.destroy();
          request.destroy();
          reject(new SafeFetchError("The website response is larger than the safe scan limit."));
          return;
        }

        response.on("data", (chunk: Buffer | string) => {
          const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
          bytes += buffer.length;
          if (bytes > MAX_RESPONSE_BYTES) {
            response.destroy(new SafeFetchError("The website response is larger than the safe scan limit."));
            return;
          }
          chunks.push(buffer);
        });
        response.on("end", () => {
          resolve({
            statusCode,
            location:
              typeof response.headers.location === "string"
                ? response.headers.location
                : undefined,
            contentType,
            body: Buffer.concat(chunks).toString("utf8"),
          });
        });
        response.on("error", reject);
      },
    );

    const overallTimer = setTimeout(() => {
      request.destroy(new SafeFetchError("The website took too long to respond."));
    }, REQUEST_TIMEOUT_MS);
    request.on("close", () => clearTimeout(overallTimer));
    request.setTimeout(REQUEST_TIMEOUT_MS, () => {
      request.destroy(new SafeFetchError("The website took too long to respond."));
    });
    request.on("error", reject);
    request.end();
  });
}

export async function fetchPublicPage(input: string): Promise<PublicPage> {
  const initial = normalizePublicUrl(input);
  let current = initial;
  const redirects: string[] = [];

  for (let hop = 0; hop <= MAX_REDIRECTS; hop += 1) {
    const addresses = await resolvePublicAddresses(current.hostname);
    const response = await requestPinnedToAddress(
      current,
      addresses[0].address,
      addresses[0].family,
    );

    if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.location) {
      if (hop === MAX_REDIRECTS) {
        throw new SafeFetchError("The website redirected too many times.");
      }
      let next: URL;
      try {
        next = normalizePublicUrl(new URL(response.location, current).toString());
      } catch (error) {
        if (error instanceof SafeFetchError) throw error;
        throw new SafeFetchError("The website returned an invalid redirect.");
      }
      redirects.push(next.toString());
      current = next;
      continue;
    }

    if (response.statusCode < 200 || response.statusCode >= 400) {
      throw new SafeFetchError(`The website returned HTTP ${response.statusCode}.`);
    }

    return {
      requestedUrl: initial.toString(),
      finalUrl: current.toString(),
      statusCode: response.statusCode,
      contentType: response.contentType,
      body: response.body,
      redirects,
    };
  }

  throw new SafeFetchError("The website could not be fetched safely.");
}
