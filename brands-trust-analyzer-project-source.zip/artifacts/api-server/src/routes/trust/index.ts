import {
  createHmac,
  randomBytes,
  timingSafeEqual,
} from "node:crypto";
import { and, count, desc, eq, lt } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  AnalyzeTrustTargetBody,
  AnalyzeTrustTargetResponse,
  DeleteTrustReportParams,
  GetTrustReportParams,
  GetTrustReportResponse,
  GetTrustSettingsResponse,
  GetTrustSummaryResponse,
  ListTrustReportsQueryParams,
  ListTrustReportsResponse,
  UpdateTrustSettingsBody,
  UpdateTrustSettingsResponse,
} from "@workspace/api-zod";
import { db, trustAnalysesTable, trustSettingsTable } from "@workspace/db";
import { hashSessionToken, runTrustAnalysis } from "./engine";
import { normalizePublicUrl, SafeFetchError } from "./safe-fetch";

const router: IRouter = Router();
const COOKIE_NAME = "trust_session";
const COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 365;
const RATE_WINDOW_MS = 10 * 60 * 1000;
const RATE_MAX_ANALYSES = 5;
const analysisAttempts = new Map<string, { startedAt: number; count: number }>();

router.use((_req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  next();
});

const DEFAULT_RETENTION_DAYS = (() => {
  const raw = process.env.TRUST_ANALYSIS_RETENTION_DAYS;
  if (raw === undefined || raw === "") return 90;
  const days = Number(raw);
  if (![7, 30, 90, 180, 365].includes(days)) {
    throw new Error(
      "TRUST_ANALYSIS_RETENTION_DAYS must be one of 7, 30, 90, 180, or 365.",
    );
  }
  return days;
})();

function signature(token: string): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET is required for private report sessions.");
  return createHmac("sha256", secret).update(token).digest("base64url");
}

function parseCookie(request: Request, name: string): string | null {
  const raw = request.headers.cookie;
  if (!raw) return null;
  for (const pair of raw.split(";")) {
    const separator = pair.indexOf("=");
    if (separator < 0 || pair.slice(0, separator).trim() !== name) continue;
    try {
      return decodeURIComponent(pair.slice(separator + 1).trim());
    } catch {
      return null;
    }
  }
  return null;
}

function validToken(value: string | null): string | null {
  if (!value) return null;
  const separator = value.lastIndexOf(".");
  if (separator < 0) return null;
  const token = value.slice(0, separator);
  const suppliedSignature = value.slice(separator + 1);
  if (!/^[A-Za-z0-9_-]{40,48}$/.test(token)) return null;
  const expected = Buffer.from(signature(token));
  const supplied = Buffer.from(suppliedSignature);
  if (expected.length !== supplied.length || !timingSafeEqual(expected, supplied)) {
    return null;
  }
  return token;
}

function getSessionOwner(request: Request, response: Response): string {
  let token = validToken(parseCookie(request, COOKIE_NAME));
  if (!token) {
    token = randomBytes(32).toString("base64url");
    const forwardedProtocol = request.get("x-forwarded-proto")?.split(",")[0]?.trim();
    const secure =
      process.env.NODE_ENV === "production" || forwardedProtocol === "https"
        ? "; Secure"
        : "";
    response.append(
      "Set-Cookie",
      `${COOKIE_NAME}=${encodeURIComponent(`${token}.${signature(token)}`)}; Path=/api/trust; HttpOnly; SameSite=Strict; Max-Age=${COOKIE_MAX_AGE_SECONDS}${secure}`,
    );
  }
  return hashSessionToken(token);
}

function isRateLimited(owner: string): boolean {
  const now = Date.now();
  const current = analysisAttempts.get(owner);
  if (!current || now - current.startedAt >= RATE_WINDOW_MS) {
    analysisAttempts.set(owner, { startedAt: now, count: 1 });
  } else if (current.count >= RATE_MAX_ANALYSES) {
    return true;
  } else {
    current.count += 1;
  }

  if (analysisAttempts.size > 2_000) {
    for (const [key, value] of analysisAttempts) {
      if (now - value.startedAt >= RATE_WINDOW_MS) analysisAttempts.delete(key);
    }
  }
  return false;
}

function toSummary(row: typeof trustAnalysesTable.$inferSelect) {
  return {
    id: row.id,
    submittedUrl: row.submittedUrl,
    domain: row.domain,
    analysisType: row.analysisType,
    riskScore: row.riskScore,
    riskLevel: row.riskLevel,
    authenticity: row.authenticity,
    confidence: row.confidence,
    summary: row.summary,
    hasAi: row.hasAi,
    createdAt: row.createdAt.toISOString(),
  };
}

function toReport(row: typeof trustAnalysesTable.$inferSelect) {
  return {
    ...toSummary(row),
    findings: row.findings,
    warningSigns: row.warningSigns,
    positiveIndicators: row.positiveIndicators,
    limitations: row.limitations,
    recommendations: row.recommendations,
    modelVersion: row.modelVersion,
    ruleSetVersion: row.ruleSetVersion,
    status: row.status,
  };
}

async function getRetentionDays(owner: string): Promise<number> {
  await db
    .insert(trustSettingsTable)
    .values({ sessionOwner: owner, retentionDays: DEFAULT_RETENTION_DAYS })
    .onConflictDoNothing();
  const [settings] = await db
    .select({ retentionDays: trustSettingsTable.retentionDays })
    .from(trustSettingsTable)
    .where(eq(trustSettingsTable.sessionOwner, owner))
    .limit(1);
  if (!settings) throw new Error("Trust settings could not be loaded.");
  return settings.retentionDays;
}

async function applyRetention(owner: string, days: number): Promise<void> {
  const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  await db
    .delete(trustAnalysesTable)
    .where(
      and(
        eq(trustAnalysesTable.sessionOwner, owner),
        lt(trustAnalysesTable.createdAt, cutoff),
      ),
    );
}

router.post("/trust/analyze", async (req, res): Promise<void> => {
  const parsed = AnalyzeTrustTargetBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.issues.length }, "Invalid trust analysis request");
    res.status(400).json({ error: "Check the submitted URL and analysis details." });
    return;
  }
  try {
    normalizePublicUrl(parsed.data.url);
    if (parsed.data.officialWebsite) normalizePublicUrl(parsed.data.officialWebsite);
  } catch (error) {
    res.status(400).json({
      error:
        error instanceof SafeFetchError
          ? error.message
          : "Enter a valid public website or profile URL.",
    });
    return;
  }

  let owner: string;
  try {
    owner = getSessionOwner(req, res);
  } catch {
    req.log.error("Private report sessions are not configured");
    res.status(503).json({ error: "Private report storage is temporarily unavailable." });
    return;
  }
  if (isRateLimited(owner)) {
    res.status(429).json({
      error: "Analysis limit reached. Please wait a few minutes before trying again.",
    });
    return;
  }

  try {
    const reportRetention = await getRetentionDays(owner);
    await applyRetention(owner, reportRetention);
    const report = await runTrustAnalysis(parsed.data);
    const [saved] = await db
      .insert(trustAnalysesTable)
      .values({
        sessionOwner: owner,
        submittedUrl: report.submittedUrl,
        domain: report.domain,
        analysisType: report.analysisType,
        riskScore: report.riskScore,
        riskLevel: report.riskLevel,
        authenticity: report.authenticity,
        confidence: report.confidence,
        summary: report.summary,
        hasAi: report.hasAi,
        findings: report.findings,
        warningSigns: report.warningSigns,
        positiveIndicators: report.positiveIndicators,
        limitations: report.limitations,
        recommendations: report.recommendations,
        modelVersion: report.modelVersion,
        ruleSetVersion: report.ruleSetVersion,
        status: report.status,
      })
      .returning();

    if (!saved) {
      req.log.error("Trust report insert returned no row");
      res.status(500).json({ error: "The analysis could not be saved." });
      return;
    }

    res.status(201).json(AnalyzeTrustTargetResponse.parse(toReport(saved)));
  } catch (error) {
    req.log.error(
      { err: error instanceof Error ? error.message : "unknown error" },
      "Trust analysis failed",
    );
    res.status(500).json({ error: "The analysis could not be completed. Please try again." });
  }
});

router.get("/trust/reports", async (req, res): Promise<void> => {
  let owner: string;
  try {
    owner = getSessionOwner(req, res);
  } catch {
    res.status(503).json({ error: "Private report storage is temporarily unavailable." });
    return;
  }
  const parsed = ListTrustReportsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "The report limit is invalid." });
    return;
  }
  try {
    await applyRetention(owner, await getRetentionDays(owner));
    const rows = await db
      .select()
      .from(trustAnalysesTable)
      .where(eq(trustAnalysesTable.sessionOwner, owner))
      .orderBy(desc(trustAnalysesTable.createdAt))
      .limit(parsed.data.limit ?? 20);
    res.json(ListTrustReportsResponse.parse(rows.map(toSummary)));
  } catch (error) {
    req.log.error({ err: error instanceof Error ? error.message : "unknown error" }, "Report list failed");
    res.status(500).json({ error: "Saved reports could not be loaded." });
  }
});

router.get("/trust/reports/:id", async (req, res): Promise<void> => {
  let owner: string;
  try {
    owner = getSessionOwner(req, res);
  } catch {
    res.status(503).json({ error: "Private report storage is temporarily unavailable." });
    return;
  }
  const params = GetTrustReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "The report identifier is invalid." });
    return;
  }
  try {
    const [row] = await db
      .select()
      .from(trustAnalysesTable)
      .where(
        and(
          eq(trustAnalysesTable.id, params.data.id),
          eq(trustAnalysesTable.sessionOwner, owner),
        ),
      )
      .limit(1);
    if (!row) {
      res.status(404).json({ error: "Report not found." });
      return;
    }
    res.json(GetTrustReportResponse.parse(toReport(row)));
  } catch (error) {
    req.log.error({ err: error instanceof Error ? error.message : "unknown error" }, "Report fetch failed");
    res.status(500).json({ error: "The report could not be loaded." });
  }
});

router.delete("/trust/reports/:id", async (req, res): Promise<void> => {
  let owner: string;
  try {
    owner = getSessionOwner(req, res);
  } catch {
    res.status(503).json({ error: "Private report storage is temporarily unavailable." });
    return;
  }
  const params = DeleteTrustReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "The report identifier is invalid." });
    return;
  }
  try {
    const [deleted] = await db
      .delete(trustAnalysesTable)
      .where(
        and(
          eq(trustAnalysesTable.id, params.data.id),
          eq(trustAnalysesTable.sessionOwner, owner),
        ),
      )
      .returning({ id: trustAnalysesTable.id });
    if (!deleted) {
      res.status(404).json({ error: "Report not found." });
      return;
    }
    res.sendStatus(204);
  } catch (error) {
    req.log.error({ err: error instanceof Error ? error.message : "unknown error" }, "Report deletion failed");
    res.status(500).json({ error: "The report could not be deleted." });
  }
});

router.get("/trust/summary", async (req, res): Promise<void> => {
  let owner: string;
  try {
    owner = getSessionOwner(req, res);
  } catch {
    res.status(503).json({ error: "Private report storage is temporarily unavailable." });
    return;
  }
  try {
    await applyRetention(owner, await getRetentionDays(owner));
    const [totals] = await db
      .select({ total: count() })
      .from(trustAnalysesTable)
      .where(eq(trustAnalysesTable.sessionOwner, owner));
    const levels = await db
      .select({
        riskLevel: trustAnalysesTable.riskLevel,
        total: count(),
      })
      .from(trustAnalysesTable)
      .where(eq(trustAnalysesTable.sessionOwner, owner))
      .groupBy(trustAnalysesTable.riskLevel);
    const recent = await db
      .select()
      .from(trustAnalysesTable)
      .where(eq(trustAnalysesTable.sessionOwner, owner))
      .orderBy(desc(trustAnalysesTable.createdAt))
      .limit(5);
    const byLevel = new Map(levels.map((level) => [level.riskLevel, level.total]));
    const response = {
      total: totals?.total ?? 0,
      low: byLevel.get("low") ?? 0,
      moderate: byLevel.get("moderate") ?? 0,
      high: byLevel.get("high") ?? 0,
      critical: byLevel.get("critical") ?? 0,
      recent: recent.map(toSummary),
    };
    res.json(GetTrustSummaryResponse.parse(response));
  } catch (error) {
    req.log.error({ err: error instanceof Error ? error.message : "unknown error" }, "Trust summary failed");
    res.status(500).json({ error: "The overview could not be loaded." });
  }
});

router.get("/trust/settings", async (req, res): Promise<void> => {
  let owner: string;
  try {
    owner = getSessionOwner(req, res);
  } catch {
    res.status(503).json({ error: "Private report storage is temporarily unavailable." });
    return;
  }
  try {
    const retention = await getRetentionDays(owner);
    await applyRetention(owner, retention);
    res.json(GetTrustSettingsResponse.parse({ retentionDays: retention }));
  } catch (error) {
    req.log.error(
      { err: error instanceof Error ? error.message : "unknown error" },
      "Trust settings could not be loaded",
    );
    res.status(500).json({ error: "Privacy settings could not be loaded." });
  }
});

router.patch("/trust/settings", async (req, res): Promise<void> => {
  let owner: string;
  try {
    owner = getSessionOwner(req, res);
  } catch {
    res.status(503).json({ error: "Private report storage is temporarily unavailable." });
    return;
  }
  const parsed = UpdateTrustSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Choose a supported report retention period." });
    return;
  }
  try {
    const [settings] = await db
      .insert(trustSettingsTable)
      .values({
        sessionOwner: owner,
        retentionDays: parsed.data.retentionDays,
      })
      .onConflictDoUpdate({
        target: trustSettingsTable.sessionOwner,
        set: {
          retentionDays: parsed.data.retentionDays,
          updatedAt: new Date(),
        },
      })
      .returning({ retentionDays: trustSettingsTable.retentionDays });
    if (!settings) throw new Error("Updated trust settings were not returned.");
    await applyRetention(owner, settings.retentionDays);
    res.json(UpdateTrustSettingsResponse.parse(settings));
  } catch (error) {
    req.log.error(
      { err: error instanceof Error ? error.message : "unknown error" },
      "Trust settings could not be updated",
    );
    res.status(500).json({ error: "Privacy settings could not be saved." });
  }
});

export default router;
